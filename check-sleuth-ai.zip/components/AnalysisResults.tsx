import React from 'react';
import type { AnalysisResult } from '../types';
import { SparklesIcon } from './icons/SparklesIcon';

interface AnalysisResultsProps {
  analysis: AnalysisResult | null;
  isLoading: boolean;
}

const InsightSection: React.FC<{title: string; insights: string[]}> = ({ title, insights }) => {
    if (!insights || insights.length === 0) return null;
    return (
        <div className="mt-6 border-t border-slate-700 pt-4">
            <h3 className="font-semibold text-slate-300 text-lg mb-3">{title}</h3>
            <ul className="space-y-2 list-disc list-inside text-slate-400">
                {insights.map((insight, index) => (
                    <li key={index}>
                        {insight}
                    </li>
                ))}
            </ul>
        </div>
    );
};

const DemoModeBanner = () => (
    <div className="bg-yellow-900/50 border border-yellow-700 text-yellow-300 px-4 py-3 rounded-lg mb-6" role="alert">
      <strong className="font-bold">Demo Mode Active: </strong>
      <span className="block sm:inline">Could not connect to the AI analysis service. Showing sample results instead.</span>
    </div>
);

export const AnalysisResults: React.FC<AnalysisResultsProps> = ({ analysis, isLoading }) => {
  if (isLoading) {
    return (
        <div className="bg-slate-800 p-6 rounded-lg border border-slate-700 shadow-lg animate-pulse">
            <div className="h-8 w-1/2 bg-slate-700 rounded mb-6"></div>
            <div className="space-y-3">
                <div className="h-4 bg-slate-700 rounded w-full mb-4"></div>
                <div className="h-6 w-1/3 bg-slate-700 rounded mb-4"></div>
                <div className="h-4 bg-slate-700 rounded w-full"></div>
                <div className="h-4 bg-slate-700 rounded w-full"></div>
                <div className="h-4 bg-slate-700 rounded w-3/4"></div>
            </div>
        </div>
    );
  }

  if (!analysis) return null;

  return (
    <div className="bg-slate-800 p-6 rounded-lg border border-slate-700 shadow-lg">
      {analysis.isMock && <DemoModeBanner />}
      
      <div className="flex items-center gap-2 mb-4">
        <SparklesIcon className="h-6 w-6 text-blue-400" />
        <h2 className="text-2xl font-bold text-slate-300">AI Analysis</h2>
      </div>
      
      <div>
        <h3 className="font-semibold text-slate-300 text-lg mb-2">Summary</h3>
        <p className="text-slate-400 leading-relaxed">{analysis.summary}</p>
      </div>
      
      <InsightSection title="Potential Bias & Data Leakage" insights={analysis.biasDetectionInsights} />
      <InsightSection title="Key Insights & Data Quality" insights={analysis.dataQualityInsights} />

    </div>
  );
};