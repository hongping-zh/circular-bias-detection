
export interface BiasScore {
  category: string;
  score: number;
  explanation: string;
}

export interface AnalysisResult {
  overall_summary: string;
  bias_scores: BiasScore[];
  suggestions: string;
}
