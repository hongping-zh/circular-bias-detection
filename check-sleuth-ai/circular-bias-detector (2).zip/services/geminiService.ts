
import { GoogleGenAI, Type } from "@google/genai";
import { AnalysisResult } from '../types';

// Assume process.env.API_KEY is available in the environment
const API_KEY = process.env.API_KEY;
if (!API_KEY) {
    throw new Error("API_KEY is not defined in the environment");
}
const ai = new GoogleGenAI({ apiKey: API_KEY });

const responseSchema = {
  type: Type.OBJECT,
  properties: {
    overall_summary: {
      type: Type.STRING,
      description: "A brief, overall summary of the bias analysis.",
    },
    bias_scores: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          category: { type: Type.STRING, description: "The category of bias, e.g., Gender, Race, Political, Age, Disability." },
          score: { type: Type.NUMBER, description: "A score from 0 (no bias detected) to 10 (strong bias detected)." },
          explanation: { type: Type.STRING, description: "A brief explanation for the score, highlighting specific words or phrases if possible." }
        },
        required: ["category", "score", "explanation"]
      },
    },
    suggestions: {
      type: Type.STRING,
      description: "Actionable suggestions for rewriting the text to make it more neutral and inclusive."
    }
  },
  required: ["overall_summary", "bias_scores", "suggestions"],
};

export async function analyzeTextForBias(text: string): Promise<AnalysisResult> {
  const prompt = `Please analyze the following text for potential bias. Evaluate it across multiple categories like gender, race, political leaning, age, and disability. Provide a numeric score for each, an explanation, a general summary, and suggestions for improvement. Respond ONLY with a JSON object that conforms to the provided schema.\n\nText to analyze:\n"""\n${text}\n"""`;

  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: responseSchema,
      temperature: 0.2,
    },
  });

  try {
    const jsonText = response.text.trim();
    // It's good practice to validate the parsed object against the expected type
    const parsedResult: AnalysisResult = JSON.parse(jsonText);
    return parsedResult;
  } catch (error) {
    console.error("Failed to parse Gemini response:", error);
    console.error("Raw response text:", response.text);
    throw new Error("The analysis returned an invalid format. Please try again.");
  }
}
