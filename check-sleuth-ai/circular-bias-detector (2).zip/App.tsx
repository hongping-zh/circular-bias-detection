
import React, { useState, useCallback } from 'react';
import { AnalysisResult } from './types';
import { analyzeTextForBias } from './services/geminiService';
import Header from './components/Header';
import AnalysisForm from './components/AnalysisForm';
import ResultsDisplay from './components/ResultsDisplay';
import Footer from './components/Footer';

const App: React.FC = () => {
  const [text, setText] = useState<string>('');
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleAnalyze = useCallback(async () => {
    if (!text.trim()) {
      setError('Please enter some text to analyze.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      const analysisResult = await analyzeTextForBias(text);
      setResult(analysisResult);
    } catch (e) {
      console.error(e);
      const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred.';
      setError(`Failed to analyze text. ${errorMessage}`);
    } finally {
      setIsLoading(false);
    }
  }, [text]);

  return (
    <div className="min-h-screen flex flex-col font-sans">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-8 md:py-12">
        <div className="max-w-4xl mx-auto">
          <AnalysisForm 
            text={text}
            setText={setText}
            onAnalyze={handleAnalyze}
            isLoading={isLoading}
          />
          <ResultsDisplay 
            result={result}
            isLoading={isLoading}
            error={error}
          />
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default App;
