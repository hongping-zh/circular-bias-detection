
import React from 'react';
import { BiasScore } from '../types';

interface BiasRadarChartProps {
  data: BiasScore[];
}

// Recharts components are loaded from CDN and available on the window object
const {
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  Legend,
  Tooltip,
  ResponsiveContainer,
} = (window as any).Recharts;

const BiasRadarChart: React.FC<BiasRadarChartProps> = ({ data }) => {
  if (!RadarChart) {
    return <div>Loading Chart Library...</div>;
  }
  
  const chartData = data.map(item => ({
    subject: item.category,
    A: item.score,
    fullMark: 10,
  }));

  return (
    <div className="w-full h-80 md:h-96">
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart cx="50%" cy="50%" outerRadius="80%" data={chartData}>
          <PolarGrid stroke="#475569" />
          <PolarAngleAxis dataKey="subject" tick={{ fill: '#94a3b8', fontSize: 14 }} />
          <PolarRadiusAxis angle={30} domain={[0, 10]} tick={{ fill: 'transparent' }} />
          <Radar name="Bias Score" dataKey="A" stroke="#a78bfa" fill="#7c3aed" fillOpacity={0.6} />
          <Tooltip 
            contentStyle={{ 
                backgroundColor: '#1e293b', 
                border: '1px solid #334155',
                borderRadius: '0.5rem',
            }}
            labelStyle={{ color: '#e2e8f0' }}
          />
          <Legend wrapperStyle={{ color: '#e2e8f0' }} />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default BiasRadarChart;
