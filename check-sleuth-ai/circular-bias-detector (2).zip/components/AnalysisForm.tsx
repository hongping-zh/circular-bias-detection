
import React from 'react';
import { SpinnerIcon } from './icons';

interface AnalysisFormProps {
  text: string;
  setText: (text: string) => void;
  onAnalyze: () => void;
  isLoading: boolean;
}

const AnalysisForm: React.FC<AnalysisFormProps> = ({ text, setText, onAnalyze, isLoading }) => {
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
        onAnalyze();
    }
  };
    
  return (
    <div className="bg-base-200 p-6 rounded-lg shadow-lg border border-base-300">
      <label htmlFor="text-input" className="block text-lg font-medium text-slate-300 mb-2">
        Enter Text for Analysis
      </label>
      <textarea
        id="text-input"
        value={text}
        onChange={(e) => setText(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder="Paste your text here... (Ctrl+Enter or Cmd+Enter to submit)"
        className="w-full h-48 p-4 bg-base-300 text-slate-200 border border-base-300 rounded-md focus:ring-2 focus:ring-brand-primary focus:border-brand-primary transition duration-200 resize-y"
        disabled={isLoading}
      />
      <div className="mt-4 flex justify-end">
        <button
          onClick={onAnalyze}
          disabled={isLoading || !text.trim()}
          className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-brand-primary hover:bg-brand-secondary focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-primary disabled:bg-base-300 disabled:cursor-not-allowed transition-all duration-200 disabled:text-slate-500"
        >
          {isLoading ? (
            <>
              <SpinnerIcon className="w-5 h-5 mr-3" />
              Analyzing...
            </>
          ) : (
            'Analyze Text'
          )}
        </button>
      </div>
    </div>
  );
};

export default AnalysisForm;
