import React, { useRef, useState } from 'react';
import { AnalysisResult } from '../types';
import BiasRadarChart from './BiasRadarChart';
import { DownloadIcon, SpinnerIcon } from './icons';

interface ResultsDisplayProps {
  result: AnalysisResult | null;
  isLoading: boolean;
  error: string | null;
}

const LoadingSkeleton: React.FC = () => (
    <div className="mt-8 p-6 bg-base-200 border border-base-300 rounded-lg shadow-lg animate-pulse">
        <div className="h-6 bg-base-300 rounded w-1/3 mb-4"></div>
        <div className="h-4 bg-base-300 rounded w-full mb-2"></div>
        <div className="h-4 bg-base-300 rounded w-5/6 mb-6"></div>
        
        <div className="flex flex-col md:flex-row gap-6 items-center">
            <div className="w-full md:w-1/2">
                <div className="w-full h-80 bg-base-300 rounded-full"></div>
            </div>
            <div className="w-full md:w-1/2 space-y-4">
                <div className="h-5 bg-base-300 rounded w-1/4"></div>
                <div className="h-4 bg-base-300 rounded w-full"></div>
                <div className="h-4 bg-base-300 rounded w-full"></div>
                <div className="h-4 bg-base-300 rounded w-2/3"></div>
            </div>
        </div>
    </div>
);

const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ result, isLoading, error }) => {
  const reportRef = useRef<HTMLDivElement>(null);
  const [isDownloading, setIsDownloading] = useState(false);

  const handleDownload = async () => {
    if (!reportRef.current || isDownloading) return;
    
    setIsDownloading(true);

    try {
        const { jsPDF } = (window as any).jspdf;
        const html2canvas = (window as any).html2canvas;

        if (!jsPDF || !html2canvas) {
            alert("PDF generation library is not loaded yet. Please try again in a moment.");
            return;
        }

        const canvas = await html2canvas(reportRef.current, {
            backgroundColor: '#0f172a', // Match the app's background
            scale: 2, // Improve resolution
        });
        
        const imgData = canvas.toDataURL('image/png');
        const pdf = new jsPDF('p', 'mm', 'a4');
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
        
        pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
        pdf.save('bias-report.pdf');
    } catch (err) {
      console.error("Failed to generate PDF", err);
      alert("Sorry, there was an error creating the PDF report.");
    } finally {
        setIsDownloading(false);
    }
  };

  if (isLoading) {
    return <LoadingSkeleton />;
  }

  if (error) {
    return (
      <div className="mt-8 p-6 bg-red-900/20 border border-red-500 rounded-lg text-red-300">
        <h3 className="font-bold">Analysis Error</h3>
        <p>{error}</p>
      </div>
    );
  }
  
  if (!result) {
    return (
        <div className="mt-8 p-12 text-center bg-base-200 border border-dashed border-base-300 rounded-lg">
            <p className="text-slate-400">Your analysis results will appear here.</p>
        </div>
    );
  }

  return (
    <div className="mt-8">
        <div className="flex justify-end mb-4">
            <button
                onClick={handleDownload}
                disabled={isDownloading}
                className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-brand-primary hover:bg-brand-secondary focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-primary disabled:bg-base-300 disabled:cursor-not-allowed transition-all duration-200 disabled:text-slate-500"
                title="Download Report as PDF"
            >
              {isDownloading ? (
                <>
                  <SpinnerIcon className="w-5 h-5 mr-3" />
                  Downloading...
                </>
              ) : (
                <>
                  <DownloadIcon className="w-5 h-5 mr-2" />
                  Download Report
                </>
              )}
            </button>
        </div>
      <div ref={reportRef} className="p-6 bg-base-200 border border-base-300 rounded-lg shadow-lg">
        <h2 className="text-2xl font-bold mb-4 text-brand-light">Bias Analysis Report</h2>

        <div className="mb-8 p-4 bg-base-300 rounded-md">
          <h3 className="text-xl font-semibold mb-2 text-slate-200">Overall Summary</h3>
          <p className="text-slate-300">{result.overall_summary}</p>
        </div>

        <div className="mb-8">
            <h3 className="text-xl font-semibold mb-4 text-center text-slate-200">Bias Score Visualization</h3>
            <BiasRadarChart data={result.bias_scores} />
        </div>

        <div className="space-y-6">
          <h3 className="text-xl font-semibold text-slate-200">Detailed Breakdown</h3>
          {result.bias_scores.map((item, index) => (
            <div key={index} className="p-4 bg-base-300 rounded-md">
              <div className="flex justify-between items-center mb-2">
                <h4 className="text-lg font-medium text-slate-200">{item.category}</h4>
                <span className={`px-3 py-1 text-sm font-bold rounded-full ${item.score > 7 ? 'bg-red-500/50 text-red-200' : item.score > 4 ? 'bg-yellow-500/50 text-yellow-200' : 'bg-green-500/50 text-green-200'}`}>
                  Score: {item.score}/10
                </span>
              </div>
              <p className="text-slate-300">{item.explanation}</p>
            </div>
          ))}
        </div>
        
        <div className="mt-8 p-4 bg-base-300 rounded-md">
            <h3 className="text-xl font-semibold mb-2 text-slate-200">Suggestions for Improvement</h3>
            <p className="text-slate-300 whitespace-pre-wrap">{result.suggestions}</p>
        </div>
      </div>
    </div>
  );
};

export default ResultsDisplay;
