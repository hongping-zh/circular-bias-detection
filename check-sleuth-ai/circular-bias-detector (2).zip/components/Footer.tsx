
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-base-200 border-t border-base-300 mt-auto">
      <div className="container mx-auto px-4 py-4">
        <p className="text-center text-sm text-slate-500">
          &copy; {new Date().getFullYear()} Circular Bias Detector. Powered by Google Gemini.
        </p>
      </div>
    </footer>
  );
};

export default Footer;
