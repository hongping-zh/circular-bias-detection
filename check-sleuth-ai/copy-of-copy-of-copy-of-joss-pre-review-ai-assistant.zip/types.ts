
export interface ReviewSection {
  title: string;
  content: string;
}

export interface JossReview {
  summary: string;
  sections: ReviewSection[];
}

export type AiProvider = 'gemini' | 'deepseek';

export interface AiService {
  generateJossReview: (repoUrl: string) => Promise<JossReview>;
  generatePrFollowupAdvice: (prUrl: string) => Promise<ReviewSection[]>;
  generateCodeOptimizationAdvice: (repoUrl: string) => Promise<ReviewSection[]>;
  analyzeDatasetForBias: () => Promise<ReviewSection[]>;
}
