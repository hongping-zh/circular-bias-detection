import type { ReviewSection, JossReview, AiService } from '../types';

// --- MOCK DATA for DeepSeek ---
const mockJossReview: JossReview = {
    summary: "This is a mock summary from DeepSeek. This mock service demonstrates how a different AI provider could be integrated. The repository shows potential but requires significant improvements in testing and documentation.",
    sections: [
        { title: "✅ 📄 Statement of Need", content: "DeepSeek agrees: The need for this software is well-articulated." },
        { title: "⚠️ ⚙️ Installation", content: "DeepSeek mock: Installation is possible but dependency conflicts are likely. Pin your dependencies." },
        { title: "❌ 🧪 Automated Tests", content: "DeepSeek mock: No tests found. This is a critical omission for any serious software project." },
    ],
};

const mockPrAdvice: ReviewSection[] = [
    { title: "General Advice", content: "This is mock advice from DeepSeek. Maintainer time is valuable. Ensure your PR is concise and addresses a single issue clearly." },
    { title: "Suggested Message", content: "Hello, checking in on this pull request. Is there anything I can do to facilitate the review process? Thank you." },
];

const mockOptimizationAdvice: ReviewSection[] = [
    { title: "🏛️ Architectural Suggestions", content: "Mock Suggestion from DeepSeek: The current architecture is monolithic. Consider a microservices approach to improve modularity and scalability." },
    { title: "✨ Readability & Pythonic Idioms", content: "Mock Suggestion from DeepSeek: Many functions are too long. Refactor them to be shorter and have a single responsibility." },
];

const mockBiasAnalysis: ReviewSection[] = [
    { title: "📊 Dataset Overview", content: "This is a mock overview from DeepSeek. The 'Adult' dataset is a standard benchmark for classification tasks." },
    { title: "🎯 Potential Sources of Bias", content: "DeepSeek Mock Analysis: The dataset contains sensitive columns like 'race' and 'sex' which can lead to discriminatory models if not handled carefully." },
    { title: "⚖️ Bias Mitigation Strategies", content: "DeepSeek Mock Strategy: Consider using techniques like disparate impact removers or reweighing to improve fairness." },
    { title: "🐍 Example Python Code", content: "Mock code from DeepSeek.\n```python\n# This is mock DeepSeek code and will not run\nfrom aif360.algorithms.preprocessing import Reweighing\n\n# Reweighing is a pre-processing technique that weights\n# the examples in different demographic groups so that they have equal\n# importance during training.\nRW = Reweighing(unprivileged_groups=unprivileged_groups,\n                privileged_groups=privileged_groups)\ndataset_transf_train = RW.fit_transform(dataset_orig_train)\n```" },
];

const simulateDelay = <T>(data: T): Promise<T> => 
    new Promise(resolve => setTimeout(() => resolve(data), 500));

// --- MOCK API FUNCTIONS ---

export const generateJossReview: AiService['generateJossReview'] = async (repoUrl: string) => {
    console.log(`DeepSeek Mock: Analyzing JOSS review for ${repoUrl}`);
    return simulateDelay(mockJossReview);
};

export const generatePrFollowupAdvice: AiService['generatePrFollowupAdvice'] = async (prUrl: string) => {
    console.log(`DeepSeek Mock: Generating PR advice for ${prUrl}`);
    return simulateDelay(mockPrAdvice);
};

export const generateCodeOptimizationAdvice: AiService['generateCodeOptimizationAdvice'] = async (repoUrl: string) => {
    console.log(`DeepSeek Mock: Generating code optimization for ${repoUrl}`);
    return simulateDelay(mockOptimizationAdvice);
};

export const analyzeDatasetForBias: AiService['analyzeDatasetForBias'] = async () => {
    console.log(`DeepSeek Mock: Analyzing dataset for bias.`);
    return simulateDelay(mockBiasAnalysis);
};
