import type { AiProvider, AiService } from '../types';
import * as gemini from './gemini';
import * as deepseek from './deepseek';

const services: Record<AiProvider, AiService> = {
  gemini: gemini,
  deepseek: deepseek,
};

export const getAiService = (provider: AiProvider): AiService => {
  const service = services[provider];
  if (!service) {
    throw new Error(`AI provider "${provider}" is not supported.`);
  }
  return service;
};
