import { GoogleGenAI, Type } from "@google/genai";
import { AnalysisResult } from '../types';

const analysisSchema = {
  type: Type.OBJECT,
  properties: {
    overall_score: {
      type: Type.INTEGER,
      description: "A numerical score from 0 (no bias) to 100 (highly biased) representing the degree of circular reasoning and logical fallacies.",
    },
    summary: {
      type: Type.STRING,
      description: "A concise, one-paragraph summary of the overall findings of the analysis.",
    },
    biased_phrases: {
      type: Type.ARRAY,
      description: "An array of objects, each detailing a specific phrase identified as biased.",
      items: {
        type: Type.OBJECT,
        properties: {
          phrase: {
            type: Type.STRING,
            description: "The exact phrase from the text that exhibits bias or circular reasoning.",
          },
          explanation: {
            type: Type.STRING,
            description: "A clear and detailed explanation of why the phrase is considered problematic, specifying the type of logical fallacy (e.g., circular reasoning, confirmation bias).",
          },
          severity: {
            type: Type.STRING,
            description: "The severity level of the bias, categorized as 'Low', 'Medium', or 'High'.",
          },
          suggestion: {
            type: Type.STRING,
            description: "A constructive suggestion for rephrasing the phrase to be more objective and logical.",
          },
        },
        required: ["phrase", "explanation", "severity", "suggestion"],
      },
    },
  },
  required: ["overall_score", "summary", "biased_phrases"],
};

export const analyzeTextForCircularBias = async (text: string): Promise<AnalysisResult> => {
  const API_KEY = process.env.API_KEY;

  if (!API_KEY) {
    throw new Error("API key not configured. Please ensure the API key is provided in your environment settings to use this feature.");
  }

  const ai = new GoogleGenAI({ apiKey: API_KEY });

  const prompt = `
    Please analyze the following text for circular reasoning, confirmation bias, and other related logical fallacies.
    Your analysis must be objective and structured. Identify specific phrases, provide a clear explanation for why each is problematic, suggest an alternative phrasing, and rate the severity.
    Also, provide an overall summary and a numerical score from 0 (no bias) to 100 (highly biased).

    Text to analyze:
    ---START TEXT---
    ${text}
    ---END TEXT---
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-pro",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: analysisSchema,
        temperature: 0.2,
      },
    });

    const responseText = response.text.trim();
    const parsedJson = JSON.parse(responseText);
    
    // Validate the structure of the parsed JSON to ensure it matches the expected AnalysisResult type.
    // This handles cases where the API might return a valid JSON but not in the expected shape.
    if (
      typeof parsedJson.overall_score !== 'number' ||
      typeof parsedJson.summary !== 'string' ||
      !Array.isArray(parsedJson.biased_phrases)
    ) {
      console.error("API response does not match expected schema:", parsedJson);
      throw new Error("Invalid response structure from API");
    }

    return parsedJson as AnalysisResult;
  } catch (error) {
    console.error("Error analyzing text with Gemini API:", error);
    if (error instanceof Error) {
        throw new Error(`Failed to analyze text. API Error: ${error.message}`);
    }
    throw new Error("An unknown error occurred while analyzing the text.");
  }
};