
export interface BiasedPhrase {
  phrase: string;
  explanation: string;
  severity: 'Low' | 'Medium' | 'High';
  suggestion: string;
}

export interface AnalysisResult {
  overall_score: number;
  summary: string;
  biased_phrases: BiasedPhrase[];
}
