import React from 'react';
import { AnalysisResult, BiasedPhrase } from '../types';
import Loader from './Loader';

interface ResultDisplayProps {
  isLoading: boolean;
  error: string | null;
  result: AnalysisResult | null;
  originalText: string;
}

const severityConfig = {
  Low: {
    color: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30',
    highlight: 'bg-yellow-500/30',
  },
  Medium: {
    color: 'bg-orange-500/20 text-orange-300 border-orange-500/30',
    highlight: 'bg-orange-500/30',
  },
  High: {
    color: 'bg-red-500/20 text-red-300 border-red-500/30',
    highlight: 'bg-red-500/30',
  },
};

const HighlightedText: React.FC<{ text: string; phrases: BiasedPhrase[] }> = ({ text, phrases }) => {
  if (!phrases || phrases.length === 0) {
    return <p className="whitespace-pre-wrap">{text}</p>;
  }

  const sortedPhrases = [...phrases].sort((a, b) => text.indexOf(a.phrase) - text.indexOf(b.phrase));
  
  let lastIndex = 0;
  // FIX: Cannot find namespace 'JSX'. Changed JSX.Element to React.ReactElement to resolve the type issue.
  const parts: (string | React.ReactElement)[] = [];

  sortedPhrases.forEach((p, i) => {
    const startIndex = text.indexOf(p.phrase, lastIndex);
    if (startIndex === -1) return;

    if (startIndex > lastIndex) {
      parts.push(text.substring(lastIndex, startIndex));
    }

    const highlightClass = severityConfig[p.severity]?.highlight || 'bg-gray-500/30';
    parts.push(
      <span key={i} className={`px-1 rounded ${highlightClass}`}>
        {p.phrase}
      </span>
    );
    lastIndex = startIndex + p.phrase.length;
  });

  if (lastIndex < text.length) {
    parts.push(text.substring(lastIndex));
  }

  return <p className="whitespace-pre-wrap leading-relaxed">{parts}</p>;
};


const ResultDisplay: React.FC<ResultDisplayProps> = ({ isLoading, error, result, originalText }) => {
  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center text-dark-text-secondary">
        <Loader />
        <p className="mt-4 text-lg">Analyzing your text...</p>
        <p className="mt-2 text-sm">This may take a moment for complex analysis.</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-full p-4 bg-red-900/20 border border-red-700 rounded-lg">
        <p className="text-red-400 text-center">{error}</p>
      </div>
    );
  }

  if (!result) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center text-dark-text-secondary p-4 border-2 border-dashed border-dark-border rounded-lg">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
        </svg>
        <h3 className="text-xl font-semibold text-dark-text-primary">Analysis Results</h3>
        <p className="mt-2 max-w-sm">Your text analysis will appear here once you submit it on the left.</p>
      </div>
    );
  }
  
  const scoreColor = result.overall_score > 75 ? 'text-red-400' : result.overall_score > 40 ? 'text-orange-400' : 'text-yellow-400';

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-dark-text-secondary mb-2">Overall Score</h3>
        <div className="bg-dark-bg p-4 rounded-lg border border-dark-border">
          <p className={`text-5xl font-bold text-center ${scoreColor}`}>{result.overall_score} <span className="text-2xl text-dark-text-secondary">/ 100</span></p>
          <p className="text-center text-dark-text-secondary mt-2">A higher score indicates a greater presence of circular reasoning or bias.</p>
        </div>
      </div>
      
      <div>
        <h3 className="text-lg font-semibold text-dark-text-secondary mb-2">Summary</h3>
        <p className="p-4 bg-dark-bg rounded-lg border border-dark-border text-dark-text-primary">{result.summary}</p>
      </div>

      <div>
        <h3 className="text-lg font-semibold text-dark-text-secondary mb-2">Highlighted Text</h3>
        <div className="p-4 bg-dark-bg rounded-lg border border-dark-border text-dark-text-primary">
          <HighlightedText text={originalText} phrases={result.biased_phrases} />
        </div>
      </div>
      
      <div>
        <h3 className="text-lg font-semibold text-dark-text-secondary mb-2">Detailed Findings</h3>
        {result.biased_phrases.length > 0 ? (
          <div className="space-y-4">
            {result.biased_phrases.map((item, index) => (
              <div key={index} className={`border rounded-lg p-4 ${severityConfig[item.severity].color}`}>
                <div className="flex justify-between items-start">
                  <p className="text-lg font-semibold italic text-dark-text-primary">"{item.phrase}"</p>
                  <span className={`text-sm font-bold px-2 py-1 rounded-full ${severityConfig[item.severity].color}`}>{item.severity}</span>
                </div>
                <div className="mt-3 space-y-3 text-sm">
                    <p><strong className="text-dark-text-secondary">Explanation:</strong> {item.explanation}</p>
                    <p><strong className="text-dark-text-secondary">Suggestion:</strong> <span className="text-green-300 italic">"{item.suggestion}"</span></p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="p-4 bg-dark-bg rounded-lg border border-dark-border text-dark-text-secondary">No specific biased phrases were identified in your text.</p>
        )}
      </div>
    </div>
  );
};

export default ResultDisplay;